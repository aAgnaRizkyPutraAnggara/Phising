<?php
$title = 'Mobile Legends: Bang Bang';
$description = 'Collect your special rewards at the MOBILE LEGENDS event. This opportunity is limited and without the need for topup. Collect your rewards now!';
$copyright = 'MOBILE LEGENDS';
$theme = '#000';
$image = 'https://cdn.jsdelivr.net/gh/arpantek/logArpan@main/mlbb-5v5.webp';
$icon = 'https://m.mobilelegends.com/static/images/favicon.ico';
?>